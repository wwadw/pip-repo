#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import os

import cv2
import numpy as np
import rosbag
import sensor_msgs.point_cloud2 as pc2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image, PointCloud2

def save_pcd(points, filename):
    """保存点云为 ASCII 格式 PCD 文件"""
    with open(filename, 'w') as f:
        f.write("# .PCD v0.7 - Point Cloud Data file format\n")
        f.write("VERSION 0.7\n")
        f.write("FIELDS x y z\n")
        f.write("SIZE 4 4 4\n")
        f.write("TYPE F F F\n")
        f.write("COUNT 1 1 1\n")
        f.write(f"WIDTH {len(points)}\n")
        f.write("HEIGHT 1\n")
        f.write("VIEWPOINT 0 0 0 1 0 0 0\n")
        f.write(f"POINTS {len(points)}\n")
        f.write("DATA ascii\n")
        
        for point in points:
            f.write(f"{point[0]:.6f} {point[1]:.6f} {point[2]:.6f}\n")

def extract_frames_from_bag(
    bag_path,
    img_output_dir,
    pcd_output_dir,
    image_topic="/usb_cam/image_raw",
    pointcloud_topic="/livox/lidar_192_168_123_100",
):
    bridge = CvBridge()
    bag_name = os.path.splitext(os.path.basename(bag_path))[0]
    
    print(f"正在处理: {bag_name}")
    
    try:
        with rosbag.Bag(bag_path, 'r') as bag:
            image_msg = None
            pointcloud_msg = None
            
            # 读取消息
            for topic, msg, t in bag.read_messages():
                if topic == image_topic and image_msg is None:
                    image_msg = msg
                elif topic == pointcloud_topic and pointcloud_msg is None:
                    pointcloud_msg = msg
                
                # 如果两个都找到了，就退出读取循环（针对单帧bag）
                if image_msg is not None and pointcloud_msg is not None:
                    break
            
            # --- 保存图像 ---
            if image_msg is not None:
                try:
                    cv_image = bridge.imgmsg_to_cv2(image_msg, "bgr8")
                    image_filename = f"{bag_name}.jpg" # 保持文件名一致
                    image_path = os.path.join(img_output_dir, image_filename)
                    cv2.imwrite(image_path, cv_image)
                    print(f"  [图片] 已保存: {image_filename}")
                except Exception as e:
                    print(f"  [图片] 保存失败: {e}")
            else:
                print("  [警告] 未找到图像消息")
            
            # --- 保存点云 ---
            if pointcloud_msg is not None:
                try:
                    points = []
                    # 提取 x, y, z 坐标
                    for point in pc2.read_points(pointcloud_msg, field_names=("x", "y", "z"), skip_nans=True):
                        points.append([point[0], point[1], point[2]])
                    
                    points = np.array(points)
                    
                    pcd_filename = f"{bag_name}.pcd" # 保持文件名一致
                    pcd_path = os.path.join(pcd_output_dir, pcd_filename)
                    save_pcd(points, pcd_path)
                    print(f"  [点云] 已保存: {pcd_filename} (点数: {len(points)})")
                except Exception as e:
                    print(f"  [点云] 保存失败: {e}")
            else:
                print("  [警告] 未找到点云消息")
                
    except Exception as e:
        print(f"处理 bag 包出错 {bag_path}: {e}")

def parse_args():
    parser = argparse.ArgumentParser(
        description="Split ROS bag files into a single image and point cloud.",
    )
    parser.add_argument(
        "--input",
        "-i",
        required=True,
        help="Bag file or directory containing .bag files.",
    )
    parser.add_argument(
        "--img-output",
        default="./extracted_data/images",
        help="Output directory for images.",
    )
    parser.add_argument(
        "--pcd-output",
        default="./extracted_data/pointclouds",
        help="Output directory for point clouds.",
    )
    parser.add_argument(
        "--image-topic",
        default="/usb_cam/image_raw",
        help="Image topic name.",
    )
    parser.add_argument(
        "--pointcloud-topic",
        default="/livox/lidar_192_168_123_100",
        help="PointCloud2 topic name.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    input_path = os.path.abspath(args.input)
    img_output_dir = os.path.abspath(args.img_output)
    pcd_output_dir = os.path.abspath(args.pcd_output)

    os.makedirs(img_output_dir, exist_ok=True)
    os.makedirs(pcd_output_dir, exist_ok=True)

    print(f"输入路径: {input_path}")
    print(f"图片输出: {img_output_dir}")
    print(f"点云输出: {pcd_output_dir}")
    print("-" * 50)

    bag_paths = []
    if os.path.isfile(input_path) and input_path.endswith(".bag"):
        bag_paths = [input_path]
    elif os.path.isdir(input_path):
        for root, dirs, files in os.walk(input_path):
            for file in files:
                if file.endswith(".bag"):
                    bag_paths.append(os.path.join(root, file))
    else:
        print("输入路径不存在或不是 .bag 文件/目录。")
        return 1

    count = 0
    for bag_path in sorted(bag_paths):
        extract_frames_from_bag(
            bag_path,
            img_output_dir,
            pcd_output_dir,
            image_topic=args.image_topic,
            pointcloud_topic=args.pointcloud_topic,
        )
        count += 1

    print("-" * 50)
    print(f"全部完成，共处理 {count} 个 bag 包。")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())