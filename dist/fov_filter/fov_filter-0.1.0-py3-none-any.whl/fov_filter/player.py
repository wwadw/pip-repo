from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Dict, Iterable, List, Optional

import rosbag
import rospy
from rosgraph_msgs.msg import Clock
from sensor_msgs.msg import PointCloud2
from std_msgs.msg import String

from fov_filter.config_io import load_config, regions_from_config
from fov_filter.pointcloud import (
    build_region_mask,
    extract_xyz,
    make_visual_cloud,
    pointcloud2_to_array,
    subset_pointcloud,
)
from fov_filter.types import FovRegion, parse_bool


class FovFilterPlayer:
    def __init__(
        self,
        bag_path: str,
        topic: str,
        out_topic: str = "/fov_filter/cloud",
        rejected_topic: str = "/fov_filter/rejected",
        visual_topic: str = "/fov_filter/visualized",
        command_topic: str = "/fov_filter/command",
        state_topic: str = "/fov_filter/state",
        rate: float = 1.0,
        loop: bool = False,
        start_paused: bool = False,
        paint_rejected: bool = False,
        publish_rejected: bool = True,
        publish_clock: bool = False,
        regions: Optional[Iterable[FovRegion]] = None,
    ) -> None:
        self.bag_path = os.path.abspath(bag_path)
        self.topic = topic
        self.out_topic = out_topic
        self.rejected_topic = rejected_topic
        self.visual_topic = visual_topic
        self.command_topic = command_topic
        self.state_topic = state_topic
        self.rate = max(1e-3, float(rate))
        self.loop = bool(loop)
        self.playing = not start_paused
        self.paint_rejected = bool(paint_rejected)
        self.publish_rejected = bool(publish_rejected)
        self.publish_clock = bool(publish_clock)
        self._lock = threading.RLock()

        self.filtered_pub = rospy.Publisher(self.out_topic, PointCloud2, queue_size=1)
        self.rejected_pub = rospy.Publisher(self.rejected_topic, PointCloud2, queue_size=1)
        self.visual_pub = rospy.Publisher(self.visual_topic, PointCloud2, queue_size=1)
        self.state_pub = rospy.Publisher(self.state_topic, String, queue_size=1, latch=True)
        self.command_sub = rospy.Subscriber(
            self.command_topic,
            String,
            self._command_callback,
            queue_size=10,
        )
        self.clock_pub = rospy.Publisher("/clock", Clock, queue_size=1) if self.publish_clock else None

        self.regions: Dict[str, FovRegion] = {}
        for region in regions or []:
            self.regions[region.name] = region

        self.frames: List[PointCloud2] = []
        self.frame_times: List[float] = []
        self.current_index = 0
        self._next_due_at: Optional[float] = None
        self.last_stats: Dict[str, Any] = {}
        self.last_command_id: Optional[str] = None

        self._load_frames()
        if not self.frames:
            raise RuntimeError(f"bag 中未找到话题 {self.topic} 的 PointCloud2 消息")

        self.publish_current_frame(reason="startup")
        self._schedule_next_frame()

    def _load_frames(self) -> None:
        if not os.path.exists(self.bag_path):
            raise FileNotFoundError(f"bag 文件不存在: {self.bag_path}")

        rospy.loginfo("加载 bag: %s", self.bag_path)
        with rosbag.Bag(self.bag_path, "r") as bag:
            count = 0
            for _, msg, bag_time in bag.read_messages(topics=[self.topic]):
                if getattr(msg, "_type", "") != "sensor_msgs/PointCloud2":
                    continue
                self.frames.append(msg)
                stamp = msg.header.stamp.to_sec()
                if stamp <= 0:
                    stamp = bag_time.to_sec()
                self.frame_times.append(float(stamp))
                count += 1
                if count % 100 == 0:
                    rospy.loginfo("已缓存 %d 帧点云", count)

        rospy.loginfo("加载完成，共 %d 帧", len(self.frames))

    def _current_msg(self) -> PointCloud2:
        return self.frames[self.current_index]

    def _current_stamp(self) -> float:
        return self.frame_times[self.current_index]

    def _schedule_next_frame(self) -> None:
        if not self.playing or len(self.frames) <= 1:
            self._next_due_at = None
            return

        next_index = self.current_index + 1
        if next_index >= len(self.frames):
            if not self.loop:
                self._next_due_at = None
                return
            next_index = 0

        delta = self.frame_times[next_index] - self.frame_times[self.current_index]
        delta = max(1e-3, delta / self.rate)
        self._next_due_at = time.monotonic() + delta

    def _advance_index(self, step: int) -> bool:
        if not self.frames:
            return False

        total = len(self.frames)
        new_index = self.current_index + int(step)
        if self.loop:
            new_index %= total
        else:
            new_index = max(0, min(total - 1, new_index))
            if new_index == self.current_index and step > 0 and self.current_index == total - 1:
                self.playing = False
                self._next_due_at = None
                return False
            if new_index == self.current_index and step < 0 and self.current_index == 0:
                self._next_due_at = None
                return False

        self.current_index = new_index
        return True

    def _apply_filter(self, msg: PointCloud2) -> Dict[str, Any]:
        array = pointcloud2_to_array(msg)
        xyz = extract_xyz(array)
        mask = build_region_mask(xyz, self.regions.values())

        accepted_array = array[mask]
        rejected_array = array[~mask]
        accepted_xyz = xyz[mask]
        rejected_xyz = xyz[~mask]

        result = {
            "filtered_msg": subset_pointcloud(msg, accepted_array),
            "rejected_msg": subset_pointcloud(msg, rejected_array),
            "visual_msg": make_visual_cloud(msg.header, accepted_xyz, rejected_xyz)
            if self.paint_rejected
            else None,
            "stats": {
                "total_points": int(array.shape[0]),
                "kept_points": int(accepted_array.shape[0]),
                "rejected_points": int(rejected_array.shape[0]),
                "enabled_regions": sum(1 for region in self.regions.values() if region.enabled),
            },
        }
        return result

    def publish_current_frame(self, reason: str = "manual") -> None:
        with self._lock:
            msg = self._current_msg()
            filtered = self._apply_filter(msg)
            self.filtered_pub.publish(filtered["filtered_msg"])
            if self.publish_rejected:
                self.rejected_pub.publish(filtered["rejected_msg"])
            if self.paint_rejected and filtered["visual_msg"] is not None:
                self.visual_pub.publish(filtered["visual_msg"])
            if self.clock_pub is not None:
                stamp = msg.header.stamp
                if stamp.to_sec() <= 0:
                    stamp = rospy.Time.from_sec(self._current_stamp())
                self.clock_pub.publish(Clock(clock=stamp))

            self.last_stats = {
                "reason": reason,
                "index": self.current_index,
                "stamp": self._current_stamp(),
                **filtered["stats"],
            }
            self._publish_state()

    def _publish_state(self) -> None:
        msg = self._current_msg()
        state = {
            "bag": self.bag_path,
            "topic": self.topic,
            "last_command_id": self.last_command_id,
            "playing": self.playing,
            "rate": self.rate,
            "loop": self.loop,
            "paint_rejected": self.paint_rejected,
            "publish_rejected": self.publish_rejected,
            "current_index": self.current_index,
            "total_frames": len(self.frames),
            "stamp": self._current_stamp(),
            "frame_id": msg.header.frame_id,
            "regions": [region.to_dict() for region in self.regions.values()],
            "last_stats": self.last_stats,
            "topics": {
                "filtered": self.out_topic,
                "rejected": self.rejected_topic,
                "visualized": self.visual_topic,
                "command": self.command_topic,
                "state": self.state_topic,
            },
        }
        self.state_pub.publish(String(data=json.dumps(state, ensure_ascii=False, sort_keys=True)))

    def _load_regions_from_config(self, path: str) -> List[FovRegion]:
        return regions_from_config(load_config(path))

    def _command_callback(self, msg: String) -> None:
        try:
            payload = json.loads(msg.data)
        except Exception as exc:
            rospy.logwarn("无法解析命令 JSON: %s", exc)
            return

        op = str(payload.get("op", "")).strip().lower()
        if not op:
            rospy.logwarn("命令缺少 op 字段")
            return

        try:
            self.last_command_id = payload.get("command_id")
            with self._lock:
                should_publish = self._handle_command(op, payload)
                if should_publish:
                    self.publish_current_frame(reason=op)
                else:
                    self._publish_state()
        except Exception as exc:
            rospy.logwarn("执行命令 %s 失败: %s", op, exc)

    def _handle_command(self, op: str, payload: Dict[str, Any]) -> bool:
        if op == "play":
            self.playing = True
            self._schedule_next_frame()
            return False

        if op == "pause":
            self.playing = False
            self._next_due_at = None
            return False

        if op == "toggle":
            self.playing = not self.playing
            self._schedule_next_frame()
            return False

        if op in {"next", "forward"}:
            self.playing = False
            self._next_due_at = None
            count = max(1, int(payload.get("count", 1)))
            self._advance_index(count)
            return True

        if op in {"prev", "back", "backward"}:
            self.playing = False
            self._next_due_at = None
            count = max(1, int(payload.get("count", 1)))
            self._advance_index(-count)
            return True

        if op == "seek":
            self.playing = False
            self._next_due_at = None
            index = int(payload["index"])
            self.current_index = max(0, min(len(self.frames) - 1, index))
            return True

        if op == "republish":
            return True

        if op == "status":
            return False

        if op == "add_region":
            region = FovRegion.from_mapping(payload["region"])
            self.regions[region.name] = region
            return True

        if op == "update_region":
            name = str(payload["name"])
            if name not in self.regions:
                raise KeyError(f"区域不存在: {name}")
            self.regions[name].update_from_mapping(payload.get("region", {}))
            renamed = self.regions[name].name
            if renamed != name:
                self.regions[renamed] = self.regions.pop(name)
            return True

        if op == "remove_region":
            name = str(payload["name"])
            self.regions.pop(name, None)
            return True

        if op == "clear_regions":
            self.regions.clear()
            return True

        if op == "set_regions":
            new_regions = parse_regions_config(payload.get("regions"))
            self.regions = {region.name: region for region in new_regions}
            return True

        if op == "load_config":
            config_path = str(payload["config_path"])
            new_regions = self._load_regions_from_config(config_path)
            self.regions = {region.name: region for region in new_regions}
            return True

        if op == "set_option":
            if "rate" in payload and payload["rate"] is not None:
                self.rate = max(1e-3, float(payload["rate"]))
            if "loop" in payload and payload["loop"] is not None:
                self.loop = parse_bool(payload["loop"], default=self.loop)
            if "paint_rejected" in payload and payload["paint_rejected"] is not None:
                self.paint_rejected = parse_bool(
                    payload["paint_rejected"], default=self.paint_rejected
                )
            if "publish_rejected" in payload and payload["publish_rejected"] is not None:
                self.publish_rejected = parse_bool(
                    payload["publish_rejected"], default=self.publish_rejected
                )
            if "playing" in payload and payload["playing"] is not None:
                self.playing = parse_bool(payload["playing"], default=self.playing)
            self._schedule_next_frame()
            return True

        raise ValueError(f"未知命令: {op}")

    def spin(self) -> None:
        tick = rospy.Rate(200)
        while not rospy.is_shutdown():
            should_publish = False
            with self._lock:
                if (
                    self.playing
                    and self._next_due_at is not None
                    and time.monotonic() >= self._next_due_at
                ):
                    should_publish = self._advance_index(1)
                    self._schedule_next_frame()
            if should_publish:
                self.publish_current_frame(reason="play")
            tick.sleep()
